import Foundation

public func publicFunction() {
    print("Hello!")
}


